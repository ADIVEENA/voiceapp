; ============================================================
; VoiceApp NSIS Installer Script
; Creates a professional Windows installer
; ============================================================

!include "MUI2.nsh"
!include "LogicLib.nsh"

; ── App Info ─────────────────────────────────────────────
Name "VoiceApp"
OutFile "VoiceApp-Setup.exe"
InstallDir "$PROGRAMFILES64\VoiceApp"
InstallDirRegKey HKLM "Software\VoiceApp" "InstallDir"
RequestExecutionLevel admin
SetCompressor /SOLID lzma

; ── Version Info ─────────────────────────────────────────
VIProductVersion "1.0.0.0"
VIAddVersionKey "ProductName"     "VoiceApp"
VIAddVersionKey "ProductVersion"  "1.0.0"
VIAddVersionKey "CompanyName"     "VoiceApp"
VIAddVersionKey "FileDescription" "Voice to Text Application"
VIAddVersionKey "FileVersion"     "1.0.0"
VIAddVersionKey "LegalCopyright"  "2026 VoiceApp"

; ── UI Settings ──────────────────────────────────────────
!define MUI_ABORTWARNING
!define MUI_ICON "..\ml\icon.ico"
!define MUI_UNICON "..\ml\icon.ico"
!define MUI_WELCOMEPAGE_TITLE "Welcome to VoiceApp"
!define MUI_WELCOMEPAGE_TEXT "VoiceApp turns your voice into text in any app.$\r$\n$\r$\nPress Ctrl+Space, speak, and your words appear anywhere.$\r$\n$\r$\nClick Next to install."
!define MUI_FINISHPAGE_RUN "$INSTDIR\VoiceApp.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Launch VoiceApp now"
!define MUI_FINISHPAGE_SHOWREADME ""
!define MUI_FINISHPAGE_TEXT "VoiceApp has been installed.$\r$\n$\r$\nPress Ctrl+Space anywhere to start recording.$\r$\nSpeak your text.$\r$\nText appears automatically!"

; ── Pages ────────────────────────────────────────────────
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "license.txt"
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

; ── Install Section ───────────────────────────────────────
Section "VoiceApp" SecMain

  SetOutPath "$INSTDIR"

  ; Copy main executable
  File "..\ml\dist\VoiceApp.exe"

  ; Copy data files
  File /nonfatal "..\ml\dictionary.json"
  File /nonfatal "..\ml\snippets.json"
  File /nonfatal "..\ml\config.json"

  ; Create Start Menu shortcut
  CreateDirectory "$SMPROGRAMS\VoiceApp"
  CreateShortcut "$SMPROGRAMS\VoiceApp\VoiceApp.lnk" \
    "$INSTDIR\VoiceApp.exe" "" "$INSTDIR\VoiceApp.exe"
  CreateShortcut "$SMPROGRAMS\VoiceApp\Uninstall VoiceApp.lnk" \
    "$INSTDIR\Uninstall.exe"

  ; Create Desktop shortcut
  CreateShortcut "$DESKTOP\VoiceApp.lnk" \
    "$INSTDIR\VoiceApp.exe" "" "$INSTDIR\VoiceApp.exe"

  ; Write registry for uninstall
  WriteRegStr HKLM "Software\VoiceApp" "InstallDir" "$INSTDIR"
  WriteRegStr HKLM \
    "Software\Microsoft\Windows\CurrentVersion\Uninstall\VoiceApp" \
    "DisplayName" "VoiceApp"
  WriteRegStr HKLM \
    "Software\Microsoft\Windows\CurrentVersion\Uninstall\VoiceApp" \
    "UninstallString" "$INSTDIR\Uninstall.exe"
  WriteRegStr HKLM \
    "Software\Microsoft\Windows\CurrentVersion\Uninstall\VoiceApp" \
    "DisplayVersion" "1.0.0"
  WriteRegStr HKLM \
    "Software\Microsoft\Windows\CurrentVersion\Uninstall\VoiceApp" \
    "Publisher" "VoiceApp"
  WriteRegDWORD HKLM \
    "Software\Microsoft\Windows\CurrentVersion\Uninstall\VoiceApp" \
    "NoModify" 1
  WriteRegDWORD HKLM \
    "Software\Microsoft\Windows\CurrentVersion\Uninstall\VoiceApp" \
    "NoRepair" 1

  ; Create uninstaller
  WriteUninstaller "$INSTDIR\Uninstall.exe"

SectionEnd

; ── Uninstall Section ─────────────────────────────────────
Section "Uninstall"

  ; Kill running app
  ExecWait 'taskkill /F /IM VoiceApp.exe' $0

  ; Remove files
  Delete "$INSTDIR\VoiceApp.exe"
  Delete "$INSTDIR\dictionary.json"
  Delete "$INSTDIR\snippets.json"
  Delete "$INSTDIR\config.json"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"

  ; Remove shortcuts
  Delete "$SMPROGRAMS\VoiceApp\VoiceApp.lnk"
  Delete "$SMPROGRAMS\VoiceApp\Uninstall VoiceApp.lnk"
  RMDir "$SMPROGRAMS\VoiceApp"
  Delete "$DESKTOP\VoiceApp.lnk"

  ; Remove registry
  DeleteRegKey HKLM "Software\VoiceApp"
  DeleteRegKey HKLM \
    "Software\Microsoft\Windows\CurrentVersion\Uninstall\VoiceApp"

  ; Remove autostart if set
  DeleteRegValue HKCU \
    "Software\Microsoft\Windows\CurrentVersion\Run" "VoiceApp"

SectionEnd
