# ============================================================
# FILE: installer/create_icon.py
# Run this to create icon.ico for the installer
# ============================================================

from PIL import Image, ImageDraw
import os

def create_voiceapp_icon():
    sizes = [16, 32, 48, 64, 128, 256]
    images = []

    for size in sizes:
        img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        s    = size

        # Background circle — dark purple
        draw.ellipse([2, 2, s-2, s-2],
                     fill="#1a1a2e", outline="#7c5cfc",
                     width=max(1, s//16))

        # Mic body
        mx   = s // 2
        mw   = max(3, s // 8)
        mh   = s // 3
        draw.rounded_rectangle(
            [mx-mw, s//8, mx+mw, s//8+mh],
            radius=mw,
            fill="#ffffff"
        )

        # Mic arc
        if s >= 32:
            aw = max(1, s // 20)
            draw.arc(
                [mx-mw*2, s//3, mx+mw*2, s//2+s//8],
                start=0, end=180,
                fill="#ffffff", width=aw
            )
            # Pole
            draw.line([mx, s//2+s//8, mx, s*3//4],
                      fill="#ffffff", width=max(1, aw))
            # Base
            draw.line([mx-mw, s*3//4, mx+mw, s*3//4],
                      fill="#ffffff", width=max(1, aw))

        images.append(img)

    # Save as .ico with all sizes
    output = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "ml", "icon.ico"
    )
    images[0].save(
        output,
        format="ICO",
        sizes=[(s, s) for s in sizes],
        append_images=images[1:]
    )
    print(f"Icon created: {output}")
    return output

if __name__ == "__main__":
    create_voiceapp_icon()
