# How to Build the VoiceApp .exe Installer

## What You Get
After following these steps, you will have:
`VoiceApp-Setup.exe` — a real Windows installer anyone can download

## Step 1: Create the App Icon
Open terminal in `C:\AI\WisperVoice\installer\` and run:
```
python create_icon.py
```
This creates `icon.ico` in your ml folder.

## Step 2: Install PyInstaller
```
pip install pyinstaller
```

## Step 3: Build the .exe
Run this from `C:\AI\WisperVoice\ml\`:
```
pyinstaller --onefile --windowed --name "VoiceApp" --icon "icon.ico" --add-data "dictionary.json;." --add-data "snippets.json;." --hidden-import "faster_whisper" --hidden-import "pyaudio" --hidden-import "pystray" --hidden-import "win32gui" --hidden-import "win32api" --hidden-import "win32con" --hidden-import "winreg" --hidden-import "keyboard" --hidden-import "spacy" --collect-all "faster_whisper" --collect-all "spacy" --noconfirm tray_app.py
```
Wait 5-10 minutes. Creates `dist\VoiceApp.exe`

## Step 4: Install NSIS (free installer maker)
Download from: https://nsis.sourceforge.io/Download
Install with all defaults.

## Step 5: Build the Installer
Right-click `installer.nsi` → Compile NSIS Script
Creates: `VoiceApp-Setup.exe`

## Step 6: Test It
Double-click `VoiceApp-Setup.exe`
It should:
- Show welcome screen
- Show license
- Choose install folder
- Install to Program Files
- Create Desktop shortcut
- Launch VoiceApp

## File Sizes (approximate)
- VoiceApp.exe:       ~150MB (includes Python + AI models)
- VoiceApp-Setup.exe: ~120MB (compressed)

## Share With Anyone
Upload `VoiceApp-Setup.exe` to:
- Google Drive (share link)
- GitHub Releases (free)
- Your website download page

Anyone on Windows 10/11 can install it.
No Python needed on their machine.
