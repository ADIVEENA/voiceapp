# ============================================================
# VoiceApp — ONE COMMAND BUILDER
# Run this in PowerShell from C:\AI\WisperVoice\
# It does everything automatically
# ============================================================

$ErrorActionPreference = "Stop"
$ProjectDir = "C:\AI\WisperVoice"
$MlDir      = "$ProjectDir\ml"
$InstDir    = "$ProjectDir\installer"

Write-Host ""
Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║    VoiceApp Installer Builder            ║" -ForegroundColor Cyan
Write-Host "║    Building your .exe now...             ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# STEP 1: Create icon
Write-Host "Step 1/4: Creating app icon..." -ForegroundColor Yellow
Set-Location $InstDir
python create_icon.py
Write-Host "  Done!" -ForegroundColor Green

# STEP 2: Install PyInstaller
Write-Host "Step 2/4: Installing PyInstaller..." -ForegroundColor Yellow
pip install pyinstaller -q
Write-Host "  Done!" -ForegroundColor Green

# STEP 3: Build exe
Write-Host "Step 3/4: Building VoiceApp.exe (5-10 min)..." -ForegroundColor Yellow
Set-Location $MlDir

$PyInstallerArgs = @(
    "--onefile",
    "--windowed",
    "--name", "VoiceApp",
    "--icon", "$MlDir\icon.ico",
    "--add-data", "$MlDir\dictionary.json;.",
    "--add-data", "$MlDir\snippets.json;.",
    "--hidden-import", "faster_whisper",
    "--hidden-import", "pyaudio",
    "--hidden-import", "pystray",
    "--hidden-import", "PIL",
    "--hidden-import", "win32gui",
    "--hidden-import", "win32api",
    "--hidden-import", "win32con",
    "--hidden-import", "winreg",
    "--hidden-import", "keyboard",
    "--hidden-import", "spacy",
    "--hidden-import", "torch",
    "--hidden-import", "numpy",
    "--hidden-import", "tkinter",
    "--collect-all", "faster_whisper",
    "--collect-all", "spacy",
    "--noconfirm",
    "tray_app.py"
)

& pyinstaller @PyInstallerArgs

if (-not (Test-Path "$MlDir\dist\VoiceApp.exe")) {
    Write-Host "ERROR: Build failed. Check errors above." -ForegroundColor Red
    exit 1
}

$size = [math]::Round((Get-Item "$MlDir\dist\VoiceApp.exe").Length / 1MB, 1)
Write-Host "  Done! VoiceApp.exe = ${size}MB" -ForegroundColor Green

# STEP 4: Check NSIS and build installer
Write-Host "Step 4/4: Building installer..." -ForegroundColor Yellow

$nsisPath = "C:\Program Files (x86)\NSIS\makensis.exe"
if (Test-Path $nsisPath) {
    Copy-Item "$MlDir\dist\VoiceApp.exe" "$InstDir\VoiceApp.exe" -Force
    & $nsisPath "$InstDir\installer.nsi"

    if (Test-Path "$InstDir\VoiceApp-Setup.exe") {
        $isize = [math]::Round((Get-Item "$InstDir\VoiceApp-Setup.exe").Length / 1MB, 1)
        Write-Host "  Done! VoiceApp-Setup.exe = ${isize}MB" -ForegroundColor Green
    }
} else {
    Write-Host ""
    Write-Host "  NSIS not installed." -ForegroundColor Yellow
    Write-Host "  Skipping installer — copying exe directly." -ForegroundColor Yellow
    Copy-Item "$MlDir\dist\VoiceApp.exe" "$InstDir\VoiceApp.exe" -Force
    Write-Host "  Your app is at: $InstDir\VoiceApp.exe" -ForegroundColor Green
}

Write-Host ""
Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  BUILD COMPLETE!                         ║" -ForegroundColor Green
Write-Host "╠══════════════════════════════════════════╣" -ForegroundColor Green
Write-Host "║                                          ║" -ForegroundColor Green
Write-Host "║  Installer: installer\VoiceApp-Setup.exe ║" -ForegroundColor Green
Write-Host "║                                          ║" -ForegroundColor Green
Write-Host "║  Share this file with anyone.            ║" -ForegroundColor Green
Write-Host "║  They double-click to install.           ║" -ForegroundColor Green
Write-Host "║  No Python needed on their machine!      ║" -ForegroundColor Green
Write-Host "║                                          ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Green

# Open the folder
explorer $InstDir
